### R code from vignette source 'qfa.Snw'

